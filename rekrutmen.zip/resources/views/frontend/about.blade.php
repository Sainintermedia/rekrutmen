<div class="container">
    <div class="row">
    <div class="col-md-6"><img src="assets/frontend/img/img1.png" class="img-center" alt="" /></div>
        <div class="col-md-6">
            <div><h2>Our Team / </h2>
            <p>Kerja sama tim atau team building adalah proses dan strategi yang dibangun untuk mewujudkan visi misi TEAM REKRUTMENT. Prinsipnya, kerja sama tim merupakan cara bekerja kreatif berbekalkan komunikasi yang baik dan kemampuan untuk memecahkan masalah yang dihadapi secara bersama-sama.</p>
            <P>Menjadi bagian dari sebuah tim hebat di tempat kerja tentu menjadi idaman setiap orang, termasuk Anda. Bayangkan jika Anda menjadi bagian dari tim ini, Anda akan bangun pagi dengan penuh semangat dan bekerja dengan penuh energi setiap hari. </P>
        </div>
            <br/>
        </div>
    </div> 

</div>