<div id="main-slider" class="flexslider">
    <ul class="slides">
      <li>
        <img src="assets/frontend/img/slides/1.jpg" alt="flexslider" /> 
        <div class="flex-caption">
            <h3>CONSULTING</h3> 
            <p>Doloribus omnis minus temporibus perfer</p>  
        </div> 
      </li>
      <li>
        <img src="assets/frontend/img/slides/2.jpg" alt="flexslider" /> 
        <div class="flex-caption">
            <h3>MEMPEKERJAKAN</h3> 
            <p>Pengembangan kepemimpinan untuk pembangunan karakter yang bertanggung jawab dan kreatif</p>  
        </div> 
      </li>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\rekrutmen\resources\views/frontend/slider.blade.php ENDPATH**/ ?>