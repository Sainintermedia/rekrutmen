<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div><h1>Kerja Sama</h1>
                <h3> Terhadap Perusahaan / Outsourching </h3>
                Team Rekrutmen merupakan inisiatif kepala desa di desa
                sumurbandung dan pada akhirnya disahkan, Keberadaan Team Rekrutmen diharapkan akan lebih 
                meningkatkan peran kelembagaan dan kerjasama 
                di lingkungan Desa Sumurbandung, terutama dalam memfasilitasi 
                tes bagi calon pekerja desa sumurbandung. Terdapat beberapa agenda yang 
                akan dikukuhkan oleh Team Rekrutmen, diantaranya penguatan 
                dan pengukuran peraturan; transfaransi;
                dan kelembagaan Team.
            </div>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rekrutmen\resources\views/frontend/jumbobox.blade.php ENDPATH**/ ?>