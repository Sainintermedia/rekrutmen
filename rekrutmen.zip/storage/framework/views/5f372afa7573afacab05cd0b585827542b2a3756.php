
	<div class="container">
		<div class="row">
		<div class="skill-home"> <div class="skill-home-solid clearfix"> 
		<div class="col-md-3 text-center">
		<div class="box"> 
		<span class="icons c1"><i class="icon-settings icons"></i></span> <div class="box-area">
		<h3>SUMURBANDUNG</h3><h5> <?php echo e($sumurbandung->count()); ?> Orang</h5> <p><?php echo e($lsumurbandung->count()); ?> Laki Laki  <?php echo e($psumurbandung->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box"> 
		<span class="icons c2"><i class="icon-login icons"></i></span> <div class="box-area">
		<h3>KRAMAT</h3><h5> <?php echo e($kramat->count()); ?> Orang</h5> <p><?php echo e($lkramat->count()); ?> Laki Laki  <?php echo e($pkramat->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box"> 
		<span class="icons c3"><i class="icon-user icons"></i></span> <div class="box-area">
		<h3>KUNIR</h3><h5> <?php echo e($kunir->count()); ?> Orang</h5> <p><?php echo e($lkunir->count()); ?> Laki Laki  <?php echo e($pkunir->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box">
		<span class="icons c4"><i class="icon-home icons"></i></span> <div class="box-area">
		<h3>BENDUNG</h3><h5> <?php echo e($bendung->count()); ?> Orang</h5> <p><?php echo e($lbendung->count()); ?> Laki Laki  <?php echo e($pbendung->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box">
		<span class="icons c4"><i class="icon-home icons"></i></span> <div class="box-area">
		<h3>SEMPUR</h3><h5> <?php echo e($sempur->count()); ?> Orang</h5> <p><?php echo e($lsempur->count()); ?> Laki Laki  <?php echo e($psempur->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box">
		<span class="icons c4"><i class="icon-home icons"></i></span> <div class="box-area">
		<h3>SARADAN</h3><h5> <?php echo e($saradan->count()); ?> Orang</h5> <p><?php echo e($lsaradan->count()); ?> Laki Laki  <?php echo e($psaradan->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box">
		<span class="icons c4"><i class="icon-home icons"></i></span> <div class="box-area">
		<h3>YANG UDAH MASUK</h3><h5> <?php echo e($udah->count()); ?> Orang</h5> <p> <?php echo e($ludah->count()); ?>  Laki Laki  <?php echo e($pudah->count()); ?>  Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		<div class="col-md-3 text-center"> 
		<div class="box">
		<span class="icons c4"><i class="icon-home icons"></i></span> <div class="box-area">
		<h3>YANG BELUM MASUK</h3><h5> <?php echo e($belum->count()); ?> Orang</h5> <p><?php echo e($lbelum->count()); ?> Laki Laki  <?php echo e($pbelum->count()); ?> Perempuan</p> <p><a href="#">Read More</a></p></div>
		</div></div>
		</div></div></div>
		</div> <?php /**PATH C:\xampp\htdocs\rekrutmen\resources\views/frontend/services.blade.php ENDPATH**/ ?>